import { RequestListSkeleton } from "./RequestCardSkeleton";

export function RequestLoadingState() {
  return <RequestListSkeleton count={6} />;
}
