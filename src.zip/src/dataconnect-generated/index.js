// Placeholder file for @dataconnect/generated
// This package is linked but not currently used
export default {};
