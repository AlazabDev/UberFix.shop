import { LandingPage } from "@/components/landing/LandingPage";

export default function Index() {
  return <LandingPage />;
}
