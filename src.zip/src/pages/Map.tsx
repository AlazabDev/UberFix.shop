import { useState, useEffect, useRef } from "react";
import { Search, User, MapPin, Phone, Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { loadGoogleMaps } from "@/lib/googleMapsLoader";

interface Technician {
  id: string;
  name: string;
  specialty: string;
  rating: number;
  reviews: number;
  hourlyRate: number;
  phone: string;
  status: "متاح الآن" | "مشغول" | "غير متاح";
  avatar?: string;
  lat: number;
  lng: number;
}

const specialties = [
  { id: "paint", label: "دهان", icon: "🎨" },
  { id: "carpentry", label: "نجار", icon: "🔨" },
  { id: "electrical", label: "كهربائي", icon: "⚡" },
  { id: "plumbing", label: "سباك", icon: "🔧" },
];

const mockTechnicians: Technician[] = [
  {
    id: "1",
    name: "أحمد حسن",
    specialty: "سباك",
    rating: 5,
    reviews: 120,
    hourlyRate: 150,
    phone: "+20 123 456 789",
    status: "متاح الآن",
    lat: 30.0444,
    lng: 31.2357,
  },
  {
    id: "2",
    name: "محمد علي",
    specialty: "كهربائي",
    rating: 4.8,
    reviews: 82,
    hourlyRate: 180,
    phone: "+20 123 456 790",
    status: "متاح الآن",
    lat: 30.0544,
    lng: 31.2457,
  },
];

export default function Map() {
  const [selectedSpecialty, setSelectedSpecialty] = useState<string | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [technicians] = useState<Technician[]>(mockTechnicians);
  const [mapError, setMapError] = useState(false);
  const mapRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<google.maps.Map | null>(null);

  useEffect(() => {
    const initMap = async () => {
      try {
        const { data } = await supabase.functions.invoke("get-maps-key");
        if (!data?.apiKey) throw new Error("No API key");

        await loadGoogleMaps(data.apiKey);

        if (mapRef.current && !mapInstanceRef.current) {
          mapInstanceRef.current = new google.maps.Map(mapRef.current, {
            center: { lat: 30.0444, lng: 31.2357 },
            zoom: 12,
            styles: [
              {
                featureType: "poi",
                stylers: [{ visibility: "off" }],
              },
            ],
          });

          // Add markers for technicians
          technicians.forEach((tech) => {
            new google.maps.Marker({
              position: { lat: tech.lat, lng: tech.lng },
              map: mapInstanceRef.current!,
              title: tech.name,
            });
          });
        }
      } catch (error) {
        console.error("Map loading error:", error);
        setMapError(true);
      }
    };

    initMap();
  }, [technicians]);

  const filteredTechnicians = technicians.filter((tech) => {
    const matchesSpecialty = !selectedSpecialty || tech.specialty === selectedSpecialty;
    const matchesSearch =
      !searchQuery ||
      tech.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      tech.specialty.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesSpecialty && matchesSearch;
  });

  return (
    <div className="min-h-screen bg-[#F4F5F7] flex flex-col" dir="rtl">
      {/* Header */}
      <header className="bg-[#0B0B3B] text-white px-6 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-[#F5BF23] rounded-full flex items-center justify-center">
            <Phone className="w-5 h-5 text-[#0B0B3B]" />
          </div>
          <div className="text-right">
            <h1 className="text-xl font-bold">UberFix.shop</h1>
            <p className="text-xs text-gray-300">خدمات الصيانة المنزلية</p>
          </div>
        </div>
        <Button
          variant="ghost"
          size="icon"
          className="text-white hover:bg-white/10"
        >
          <User className="w-5 h-5" />
        </Button>
      </header>

      {/* Search Bar */}
      <div className="bg-white px-6 py-4 shadow-sm">
        <div className="relative max-w-4xl mx-auto">
          <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
          <Input
            type="text"
            placeholder="ابحث عن خدمة أو موقع..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pr-10 h-12 text-right"
          />
        </div>
      </div>

      {/* Specialty Filters */}
      <div className="bg-white border-b border-gray-200 px-6 py-3">
        <div className="flex gap-2 overflow-x-auto">
          {specialties.map((specialty) => (
            <Button
              key={specialty.id}
              variant={selectedSpecialty === specialty.label ? "default" : "outline"}
              onClick={() =>
                setSelectedSpecialty(
                  selectedSpecialty === specialty.label ? null : specialty.label
                )
              }
              className={`whitespace-nowrap ${
                selectedSpecialty === specialty.label
                  ? "bg-[#0B0B3B] text-white hover:bg-[#0B0B3B]/90"
                  : "border-gray-300"
              }`}
            >
              <span className="mr-2">{specialty.icon}</span>
              {specialty.label}
            </Button>
          ))}
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar - Technicians List */}
        <aside className="w-80 bg-white border-l border-gray-200 overflow-y-auto">
          <div className="p-4">
            <h2 className="text-lg font-bold text-[#0B0B3B] mb-1">
              الخدمات المتاحة ({filteredTechnicians.length})
            </h2>
            <p className="text-sm text-gray-500 mb-4">
              اختر فني من القائمة أدناه
            </p>

            <div className="space-y-3">
              {filteredTechnicians.map((tech) => (
                <Card key={tech.id} className="p-4 hover:shadow-md transition-shadow">
                  <div className="flex gap-3">
                    <Avatar className="w-12 h-12">
                      <AvatarImage src={tech.avatar} />
                      <AvatarFallback className="bg-[#F5BF23] text-[#0B0B3B]">
                        {tech.name.split(" ")[0][0]}
                      </AvatarFallback>
                    </Avatar>

                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <h3 className="font-semibold text-[#0B0B3B]">{tech.name}</h3>
                        <Badge
                          variant="secondary"
                          className={
                            tech.status === "متاح الآن"
                              ? "bg-green-100 text-green-700"
                              : "bg-gray-100 text-gray-700"
                          }
                        >
                          {tech.status}
                        </Badge>
                      </div>

                      <p className="text-sm text-gray-600 mb-2">{tech.specialty}</p>

                      <div className="flex items-center gap-3 text-sm mb-2">
                        <div className="flex items-center gap-1">
                          <Star className="w-4 h-4 fill-[#F5BF23] text-[#F5BF23]" />
                          <span className="font-medium">{tech.rating}</span>
                          <span className="text-gray-500">({tech.reviews} تقييم)</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between">
                        <span className="text-sm text-gray-600">
                          {tech.hourlyRate} جنيه/ساعة
                        </span>
                        <Button
                          size="sm"
                          className="bg-[#0B0B3B] hover:bg-[#0B0B3B]/90 text-white h-8"
                        >
                          <Phone className="w-3 h-3 ml-1" />
                          اتصل
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </aside>

        {/* Map Area */}
        <main className="flex-1 relative">
          {mapError ? (
            <div className="absolute inset-0 flex items-center justify-center bg-gray-100">
              <div className="text-center p-8 bg-white rounded-lg shadow-md max-w-md">
                <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <MapPin className="w-8 h-8 text-red-500" />
                </div>
                <h3 className="text-xl font-bold text-[#0B0B3B] mb-2">
                  عذرًا، حدث خطأ!
                </h3>
                <p className="text-gray-600">
                  لم يمكن تحميل خريطة Google. يرجى المحاولة مرة أخرى لاحقاً.
                </p>
              </div>
            </div>
          ) : (
            <div ref={mapRef} className="w-full h-full" />
          )}
        </main>
      </div>

      {/* Bottom Navigation */}
      <nav className="bg-white border-t border-gray-200 px-6 py-3 flex items-center justify-around">
        <Button variant="ghost" className="flex flex-col items-center gap-1 text-xs">
          <User className="w-5 h-5" />
          <span>الملف الشخصي</span>
        </Button>
        <Button variant="ghost" className="flex flex-col items-center gap-1 text-xs">
          <MapPin className="w-5 h-5" />
          <span>الفواتير</span>
        </Button>
        <Button variant="ghost" className="flex flex-col items-center gap-1 text-xs">
          <Star className="w-5 h-5" />
          <span>الخدمات المكتملة</span>
        </Button>
        <Button variant="ghost" className="flex flex-col items-center gap-1 text-xs">
          <Phone className="w-5 h-5" />
          <span>تتبع الطلبات</span>
        </Button>
        <Button
          className="flex flex-col items-center gap-1 text-xs bg-[#0B0B3B] hover:bg-[#0B0B3B]/90 text-white px-6"
        >
          <MapPin className="w-5 h-5" />
          <span>الخريطة</span>
        </Button>
      </nav>
    </div>
  );
}
